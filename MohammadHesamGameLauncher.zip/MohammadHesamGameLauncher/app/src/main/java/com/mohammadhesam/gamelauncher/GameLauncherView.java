package com.mohammadhesam.gamelauncher;

import android.content.*;import android.content.pm.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import java.util.*;

public class GameLauncherView extends View {
    Paint p=new Paint(3); MainActivity a; ArrayList<ResolveInfo> games=new ArrayList<>(); Bitmap face;
    int purple=Color.rgb(124,77,255), cyan=Color.rgb(0,210,255);
    GameLauncherView(MainActivity c){super(c);a=c; face=BitmapFactory.decodeResource(getResources(),R.drawable.profile); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    void addGame(ResolveInfo r){ if(!games.contains(r)) games.add(r); invalidate(); }
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(size);p.setColor(color);p.setTextAlign(align);c.drawText(s,x,y,p);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
    @Override protected void onDraw(Canvas c){super.onDraw(c); int w=getWidth(),h=getHeight(); c.drawColor(Color.rgb(9,11,16));
        // Header: two equal halves, Minecraft / Call of Duty inspired, using the user's portrait as the source image.
        p.setShader(new LinearGradient(0,0,w/2,0,Color.rgb(25,80,45),Color.rgb(75,35,105),Shader.TileMode.CLAMP));c.drawRect(0,0,w/2,250,p);p.setShader(null);
        p.setShader(new LinearGradient(w/2,0,w,0,Color.rgb(55,25,85),Color.rgb(18,28,55),Shader.TileMode.CLAMP));c.drawRect(w/2,0,w,250,p);p.setShader(null);
        if(face!=null){Rect src=new Rect(0,0,face.getWidth(),face.getHeight()); Rect dst=new Rect(0,30,w/2,220); c.drawBitmap(face,src,dst,p); dst=new Rect(w/2,30,w,220); c.drawBitmap(face,src,dst,p);}
        p.setColor(Color.argb(145,0,0,0));c.drawRect(0,0,w/2,250,p);c.drawRect(w/2,0,w,250,p);
        text(c,"MINECRAFT",w/4,55,22,Color.WHITE,Paint.Align.CENTER);text(c,"CALL OF DUTY",w*3/4,55,20,Color.WHITE,Paint.Align.CENTER);
        text(c,"محمد حسام",w/2,285,30,Color.WHITE,Paint.Align.CENTER);text(c,"گیم لانچر",w/2,320,18,Color.LTGRAY,Paint.Align.CENTER);
        // Add button
        round(c,24,345,w-24,410,22,purple);text(c,"＋  افزودن بازی",w/2,387,20,Color.WHITE,Paint.Align.CENTER);
        if(games.isEmpty()){text(c,"هنوز بازی‌ای اضافه نشده",w/2,480,18,Color.GRAY,Paint.Align.CENTER);text(c,"از دکمه بالا بازی‌های نصب‌شده را انتخاب کن",w/2,515,14,Color.GRAY,Paint.Align.CENTER);}
        float y=445; for(ResolveInfo r:games){ if(y+90>h)break; round(c,24,y,w-24,y+78,20,Color.rgb(20,23,32)); Drawable icon=r.loadIcon(a.getPackageManager()); icon.setBounds(40,(int)y+12,104,(int)y+76); icon.draw(c);text(c,r.loadLabel(a.getPackageManager()).toString(),125,y+38,18,Color.WHITE,Paint.Align.LEFT);round(c,w-130,y+17,w-40,y+61,16,Color.rgb(35,39,52));text(c,"اجرا",w-85,y+46,15,Color.WHITE,Paint.Align.CENTER);y+=92;}
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(); if(y>=345&&y<=410){a.showApps();return true;} float yy=445;for(ResolveInfo r:games){if(y>=yy&&y<=yy+78&&x>getWidth()-150){a.launch(r.activityInfo.packageName);return true;}yy+=92;}return true;}
}
