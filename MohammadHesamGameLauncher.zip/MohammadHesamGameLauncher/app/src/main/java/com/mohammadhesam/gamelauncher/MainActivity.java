package com.mohammadhesam.gamelauncher;

import android.app.*;import android.os.*;import android.content.*;import android.content.pm.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import java.util.*;

public class MainActivity extends Activity {
    GameLauncherView view;
    @Override public void onCreate(Bundle b){super.onCreate(b); view=new GameLauncherView(this); setContentView(view);}
    public void showApps(){
        final ArrayList<ResolveInfo> apps=new ArrayList<>();
        Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:getPackageManager().queryIntentActivities(i,0)){ if(!r.activityInfo.packageName.equals(getPackageName())) apps.add(r); }
        Collections.sort(apps,(a,c)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(c.loadLabel(getPackageManager()).toString()));
        String[] names=new String[apps.size()]; for(int n=0;n<apps.size();n++) names[n]=apps.get(n).loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this).setTitle("➕ افزودن بازی").setItems(names,(d,w)->{view.addGame(apps.get(w));}).setNegativeButton("بستن",null).show();
    }
    public void launch(String pkg){ try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null) startActivity(i);}catch(Exception ignored){} }
}
